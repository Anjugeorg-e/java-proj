package Office_project;

import java.util.ArrayList;
import org.hamcrest.core.IsNull;

public class Project {
    private String projectName;
    private String leadName;
    private String status;

    ArrayList<Employee> projectMembers = new ArrayList<>();
    ArrayList<Technology> technologiesUsed = new ArrayList<>();

    public Project(String projectName, String leadName) {
        this.projectName = projectName;
        this.leadName = leadName;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getLeadName() {
        return leadName;
    }

    public void setLeadName(String leadName) {
        this.leadName = leadName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void addEmployeeToProject(Employee employee) {
        if (employee.getProject() == null)
            this.projectMembers.add(employee);
        employee.setProject(this);
    }

    public void removeEmployeeFromProject(Employee employee) {
        this.projectMembers.remove(employee);
    }

    public void addTechnologiesForProject(Technology technology) {
        this.technologiesUsed.add(technology);
    }

}
