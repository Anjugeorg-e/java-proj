package librarymanagement;

import java.util.ArrayList;

public class Category {

    private String Type;
    ArrayList<Book> booksInCategory = new ArrayList<>();
    ArrayList<Book>sameBooksInCategory = new ArrayList<>();

    public void addBookToCategory() {
        // .........
    }

    public void removeBookFromCategory() {
        // ............
    }

    public boolean searchBookFromCategory(String bookName) {
        // .....
        return true;
    }

    public int noOfBooksInCategory() {
        // ..........

        return booksInCategory.size();
    }

    public int noOfSameBooks(){
        return sameBooksInCategory.size();
    }

}
