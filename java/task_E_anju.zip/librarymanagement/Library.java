package librarymanagement;

import java.util.ArrayList;

public class Library {

    // variables
    private String libraryName;
    ArrayList<Category> booksInLibrary = new ArrayList<>();
    ArrayList<Member> membersInLibrary = new ArrayList<>();


    // getters

    
    public ArrayList<Category> getBooksInLibrary() {
        return booksInLibrary;
    }

    public ArrayList<Member> getMembersInLibrary() {
        return membersInLibrary;
    }
    

    // methods

    public void addCategoryToLibrary() {
        // ................
    }

    public void removeCateogryFromLibrary() {
        // .............
    }

    public void addMemeberToLibrary() {
        // ............
    }

    public void removeMemberFromLibrary() {
        // .............
    }

}
